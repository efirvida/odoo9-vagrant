[![Build Status](https://travis-ci.org/OCA/runbot-addons.svg?branch=8.0)](https://travis-ci.org/OCA/runbot-addons)
[![Coverage Status](https://img.shields.io/coveralls/OCA/runbot-addons.svg)](https://coveralls.io/r/OCA/runbot-addons?branch=8.0)

Odoo modules for runbot
========================

Dependencies
------------
* Odoo repositories
     * [odoo-extra](https://github.com/odoo/odoo-extra)
* Dependencies
     * Python
         * matplotlib (through runbot)
